class Pet < ApplicationRecord
end
