class WelcomeController < ApplicationController
  def index
  end

  def about
  end

  def contact
  end
end
